<?php
session_start();

if (isset($_SESSION['live'])) {
  header("Location: /dashboard/data/home.php");
}

if (isset($_POST['login'])) {
  $user = $_POST['user'];
  $pass = $_POST['pass'];

  // Get user's IP address
  $ip = $_SERVER['REMOTE_ADDR'];

  // Read login credentials from JSON file
  $credentials = file_get_contents('B4BYLOG.json');
  $credentials = json_decode($credentials, true);

  // Check if provided credentials match any entry
  $loggedIn = false;
  foreach ($credentials['users'] as &$userData) {
    if ($user == $userData['user'] && $pass == $userData['pass']) {
      if (!isset($userData['ip']) || $userData['ip'] === "") {
        // If IP is not set or empty, save the current IP
        $userData['ip'] = $ip;
        file_put_contents('B4BYLOG.json', json_encode($credentials, JSON_PRETTY_PRINT));
      } elseif ($ip != $userData['ip']) {
        // If IP is set but doesn't match the current IP, deny login
        echo '<script type="text/javascript"> window.alert("Login not allowed from this IP address.");</script>';
        exit(); // Exit to prevent further execution
      }

      $_SESSION['live'] = $user;
      header("Location: /dashboard/");
      $loggedIn = true;
      exit(); // Exit to prevent further execution
    }
  }

  // If no matching user found
  echo '<script type="text/javascript"> window.alert("Please, Check the Username and Password");</script>';
}
?>





<!DOCTYPE html>
<html :class="{ 'theme-dark': dark }" x-data="data()" lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Dashboard - Login</title>
    <link rel="stylesheet" href="styles.css" />
<link rel="icon" href="../home/icon.png">
<link rel="shortcut icon" href="../home/icon.png" type="image/x-icon">
    <script
      src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.x.x/dist/alpine.min.js"
      defer
    ></script>
    <script src="script.js"></script>
  </head>
  <body>
    <div class="flex items-center min-h-screen p-6 bg-gray-50 dark:bg-gray-900">
      <div
        class="flex-1 h-full max-w-4xl mx-auto overflow-hidden bg-white rounded-lg shadow-xl dark:bg-gray-800"
      >
                  
        <div class="flex flex-col overflow-y-auto md:flex-row">
          <div class="flex items-center justify-center p-6 sm:p-12 md:w-1/2">
            <div class="w-full">
              <h1
                class="mb-4 text-xl font-semibold text-gray-700 dark:text-gray-200"
              >
                Login
              </h1>
                  <form class="user" action="" method="post">

          <label class="block text-sm">
                <span class="text-gray-700 dark:text-gray-400">Username</span>
<input type="text" name="user" class="block w-full mt-1 text-sm dark:border-gray-600 dark:bg-gray-700 focus:border-purple-400 focus:outline-none focus:shadow-outline-purple dark:text-gray-300 dark:focus:shadow-outline-gray form-input" placeholder="Username" value="" required>
    </label>

              </label>
              <label class="block mt-4 text-sm">
                <span class="text-gray-700 dark:text-gray-400">Password</span>
                <input type="password" name="pass" class="block w-full mt-1 text-sm dark:border-gray-600 dark:bg-gray-700 focus:border-purple-400 focus:outline-none focus:shadow-outline-purple dark:text-gray-300 dark:focus:shadow-outline-gray form-input" placeholder="***************">
              </label>


                                <button style="background-color:#ff4d00" type ="submit" name="login" class="block w-full px-4 py-2 mt-4 text-sm font-medium leading-5 text-center text-white transition-colors duration-150 bg-purple-600 border border-transparent rounded-lg active:bg-purple-600 hover:bg-purple-700 focus:outline-none focus:shadow-outline-purple">Login</button>
</form>
              <hr class="my-8" />


              <p class="mt-4">
                <a style="color:#ff4d00"
                  class="text-sm font-medium text-purple-600 dark:text-purple-400 hover:underline"
                  href="https://t.me/fbyme"
                >
                  Forgot your password?
                </a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>