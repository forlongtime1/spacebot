<?php
session_start();


// Oturum açılmamışsa login sayfasına yönlendir
if (!isset($_SESSION['live'])) {
    header("Location: /dashboard");
    exit;
}

// Get user's IP address
$ip = $_SERVER['REMOTE_ADDR'];

// Read login credentials from JSON file
$credentials = file_get_contents('B4BYLOG.json');
$credentials = json_decode($credentials, true);

// Check if user's IP address is present in the JSON file
$ipFound = false;
foreach ($credentials['users'] as &$userData) {
    if ($ip == $userData['ip']) {
        $ipFound = true;
        break;
    }
}

// If IP is not found in the JSON file, destroy the session and redirect to the dashboard
if (!$ipFound) {
    session_destroy();
    header("Location: /index.php");
    exit;
}

?>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Plate Lookup</title>
    <link rel="stylesheet" href="style1.css">
    <script src="script1.js" defer></script>
</head>
  <body>

<?php

// URL to send the POST request
$url = 'https://feye.pro/erbilpt.php';

// Initialize cURL session
$ch = curl_init();

// Define a variable to hold the response
$response = '';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get plate number and vehicle type from the form
    $plate = $_POST['plate'];
    $inputType = $_POST['inputType'];

    // Form data to be sent with the request
    $form_data = array(
        'plate' => $plate,
        'inputType' => $inputType
    );

    // Cookie to be included in the request
    $cookie = 'PHPSESSID=dj8qvrpoqas47tniv3165ul20o';

    // Set the URL
    curl_setopt($ch, CURLOPT_URL, $url);

    // Set request method to POST
    curl_setopt($ch, CURLOPT_POST, true);

    // Set the form data
    curl_setopt($ch, CURLOPT_POSTFIELDS, $form_data);

    // Set the cookie
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);

    // Return response as a string
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    // Execute the request
    $response = curl_exec($ch);

    // Check if the request was successful
    if ($response === false) {
        echo 'Error: ' . curl_error($ch);
    }
}

// Close cURL session
curl_close($ch);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Plate Lookup</title>
    <script>
        function copyResult() {
            var resultText = document.getElementById("result");
            resultText.select();
            resultText.setSelectionRange(0, 99999); /* For mobile devices */
            document.execCommand("copy");
            alert("Copied the result: " + resultText.value);
        }
    </script>
</head>

<body>
    <form method="POST" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
        <label for="plate">Plate Number:</label>
        <input type="text" id="plate" name="plate" required><br><br>
        <label for="inputType">Vehicle Type:</label>
        <select name="inputType">
            <option value="regular">خصوصي</option>
            <option value="taxi">تەکسی</option>
            <option value="7ml">حمل</option>
        </select><br><br>
        <input type="submit" value="Submit">
    </form>

    <!-- Display the result -->
    <?php if (!empty($response)) { 
        // Decode the JSON response
        $decodedResponse = json_decode($response, true);
        ?>
        <textarea id="result" readonly><?php echo json_encode($decodedResponse, JSON_UNESCAPED_UNICODE); ?></textarea>
        <button onclick="copyResult()">Copy Result</button>
    <?php } ?>
</body>

</html>