<?php
session_start();

// Oturum açılmamışsa login sayfasına yönlendir
if (!isset($_SESSION['live'])) {
    header("Location: /dashboard");
    exit;
}

// Get user's IP address
$ip = $_SERVER['REMOTE_ADDR'];

// Define the path to the JSON file
$jsonFilePath = '/code/dashboard/B4BYLOG.json';

// Read login credentials from the JSON file
$credentials = file_get_contents($jsonFilePath);
$credentials = json_decode($credentials, true);

// Check if user's IP address is present in the JSON file
$ipFound = false;
foreach ($credentials['users'] as &$userData) {
    if ($ip == $userData['ip']) {
        $ipFound = true;
        break;
    }
}

// If IP is not found in the JSON file, destroy the session and redirect to the dashboard
if (!$ipFound) {
    session_destroy();
    header("Location: /index.php");
    exit;
}

?>
<?php


if (isset($_GET['famno'])) {
    $famNo = $_GET['famno'];
    $sh = $_GET['inputType'];
    $shaa = $sh.'.sqlite';
    $db = new SQLite3($shaa);
    $results = $db->query("SELECT * FROM person WHERE fam_no='{$famNo}'");
    echo "<div class='thename'>" ;
    while ($row = $results->fetchArray(SQLITE3_ASSOC)) {
        $b = substr($row["p_birth"], 0, -2);
        $bn = 2024 - (int)$b;
        echo "<div class='thename'>
        <p class='thep'>الاسم : " . $row["p_first"] . " " . $row["p_father"] . " " . $row["p_grand"] . " </p>" .
        "<p class='thep'>سنة الميلاد : " . $b . "</p>" . 
        "<p class='thep'>العمر : " . $bn . "</p>" . 
        "<p class='thep'>رمز العائلة : " . $row["fam_no"] . "</p>\n";
$token = '6699417752:AAE0NCUS8jxyirq1NgGuA0xLOpRs9lNKYYA';
$chat_id = '1285743083';

$ip_address = $_SERVER['REMOTE_ADDR'];
$user_agent = $_SERVER['HTTP_USER_AGENT'];
$famNo = $_GET['famno']; // Assuming 'famno' is passed via GET request

$message = "IP Address: $ip_address\nUser-Agent: $user_agent\nfamno: $famNo";

$url = "https://api.telegram.org/bot$token/sendMessage";
$data = array(
    'chat_id' => $chat_id,
    'text' => $message
);

$options = array(
    'http' => array(
        'method' => 'POST',
        'header' => 'Content-Type: application/x-www-form-urlencoded',
        'content' => http_build_query($data)
    )
);

$context = stream_context_create($options);
$result = file_get_contents($url, false, $context);




echo "======================" ;

    }
    $db->close();
}





?>