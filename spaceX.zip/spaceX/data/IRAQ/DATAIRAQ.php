<?php
session_start();

// Oturum açılmamışsa login sayfasına yönlendir
if (!isset($_SESSION['live'])) {
    header("Location: /dashboard");
    exit;
}

// Get user's IP address
$ip = $_SERVER['REMOTE_ADDR'];

// Define the path to the JSON file
$jsonFilePath = '/code/dashboard/B4BYLOG.json';

// Read login credentials from the JSON file
$credentials = file_get_contents($jsonFilePath);
$credentials = json_decode($credentials, true);

// Check if user's IP address is present in the JSON file
$ipFound = false;
foreach ($credentials['users'] as &$userData) {
    if ($ip == $userData['ip']) {
        $ipFound = true;
        break;
    }
}

// If IP is not found in the JSON file, destroy the session and redirect to the dashboard
if (!$ipFound) {
    session_destroy();
    header("Location: /index.php");
    exit;
}

?>
<html>
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" 
      content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
     <link rel="stylesheet" media="screen" href="https://fontlibrary.org/face/droid-arabic-kufi" type="text/css"/>
    <link rel="stylesheet"  href="style.css">
  </head>
  <body>




<center>
    <div class="form">
        <form id="myForm">
            <input placeholder="اسم الشخص" name="name" size="30" type="text" value="" id="name"  required> 
            <input placeholder="اسم الأب" name="fname" size="30" type="text" value="" id="fname" required/>
            <input placeholder="اسم الجد" name="gname" size="30" type="text" value="" id="gname" />
            <input placeholder="تاريخ الولادة" name="birth" size="30" type="text" id="birth" value="" required/>
 <select id="inputType" name="inputType">
    <option value="erbil">Erbil</option>
    <option value="slemani">slemani</option>
    <option value="duhok">duhok</option>
    <option value="kirkuk">kirkuk</option>
    <option value="salahaldin">salahaldin</option>
    <option value="babil">babil</option>
    <option value="alanbar">alanbar</option>
    <option value="aldiwaniyah">aldiwaniyah</option>
    <option value="najaf">najaf</option>
    <option value="wasit">wasit</option>
    <option value="dhiqar">dhiqar</option>
    <option value="karbala">karbala</option>
    <option value="mesan">mesan</option>
    <option value="muthana">muthana</option>
    <option value="balad">balad</option>
    <option value="basra">basra</option>
    <option value="diyala">diyala</option>
    <option value="mousl">mousl</option>
  </select>
 <button  class="btt" type="submit" name="submit" id="submitBtn">بحث 🔎</button>
 </form> </div>
<div class="theload">
<div class="lds-roller"><div></div><div></div><div></div><div></div><div></div><div></div><div></div>
<p class="load">بحث</p>
</div> 
</div>
<div id='response'></div>
<div id='fam-search-results'></div>


 

    </script>
<script>
  const form = document.querySelector('#myForm');
  const submitBtn = document.querySelector('#submitBtn');
  let loading = document.querySelector('.theload');

 
    

  submitBtn.addEventListener('click', (event) => { 
      if(document.getElementById('birth').value != "" && document.getElementById('name').value != ""){
          document.getElementById('fam-search-results').innerHTML = "";
          
      
      loading.style.visibility='visible';
    event.preventDefault();
    
    const formData = new FormData(form);
    
    fetch('me.php', {
      method: 'POST',
      body: formData
    })
    .then(response => response.text())
    .then(data => {
        
 document.getElementById('response').innerHTML = data;   
 loading.style.visibility='hidden';
   // another code 
var searchBtns = document.querySelectorAll('.btn');
searchBtns.forEach(function(btn) {
    btn.addEventListener('click', function() {
        var famNo = this.value;
        var inputType = document.getElementById('inputType').value; // Define inputType here

        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function() {
            if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
                document.getElementById('fam-search-results').innerHTML = xhr.responseText;
            }
        };

        xhr.open('GET', 'search.php?famno='+famNo+'&inputType='+ inputType, true);
        xhr.send();
    });
});
        
    })
    .catch(error => console.error(error));
document.getElementById('name').value = "";
document.getElementById('fname').value = ""; 
document.getElementById('gname').value = "";
document.getElementById('birth').value = "";
      
      
}
});
  

</script>

  </body>
</html>