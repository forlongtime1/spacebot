<?php
session_start();

// Oturum açılmamışsa login sayfasına yönlendir
if (!isset($_SESSION['live'])) {
    header("Location: /dashboard");
    exit;
}

// Get user's IP address
$ip = $_SERVER['REMOTE_ADDR'];

// Define the path to the JSON file
$jsonFilePath = '/code/dashboard/B4BYLOG.json';

// Read login credentials from the JSON file
$credentials = file_get_contents($jsonFilePath);
$credentials = json_decode($credentials, true);

// Check if user's IP address is present in the JSON file
$ipFound = false;
foreach ($credentials['users'] as &$userData) {
    if ($ip == $userData['ip']) {
        $ipFound = true;
        break;
    }
}

// If IP is not found in the JSON file, destroy the session and redirect to the dashboard
if (!$ipFound) {
    session_destroy();
    header("Location: /index.php");
    exit;
}

?>
<?php
if(!empty($_POST)){

$name = $_POST['name'] ;
$fname = $_POST['fname'] ;
$gname = $_POST['gname'] ;
$birth = $_POST['birth'] ;
$shar = $_POST['inputType'] ;
$birth = $birth . "00";


class MyDB extends SQLite3
{
    function __construct($sha)
    {
        $this->open($sha);
    }
}








$sha = $shar.'.sqlite';
$db = new MyDB($sha);

 
   if(!$db){
      echo $db->lastErrorMsg();
      print_r("NONE");
   } else {
     
   }

   $sql =<<<EOF
      SELECT * FROM person WHERE p_first LIKE '%{$name}%' COLLATE NOCASE AND p_father LIKE '%{$fname}%' COLLATE NOCASE AND  p_grand LIKE '%{$gname}%' COLLATE NOCASE AND p_birth='{$birth}';
EOF;

   $ret = $db->query($sql);
   while($row = $ret->fetchArray(SQLITE3_ASSOC) ){
    $b = substr($row["p_birth"], 0, -2);
    $bn = 2024 - (int)$b;
    echo "<div class='thename'>
        <p class='thep'>الاسم : " . $row["p_first"] . " " . $row["p_father"] . " " . $row["p_grand"] . " </p>" . 
        "<p class='thep'>سنة الميلاد : " . $b . "</p>" . 
        "<p class='thep'>العمر : " . $bn . "</p>" . 
        "<p class='thep'>رمز العائلة : " . $row["fam_no"] ."</p><center><button class='btn' value='".$row["fam_no"]."'>بحث</button></center></div>". "\n";

      
         $famno = $row["fam_no"] ;

   }


 $mee =  '$sqll =<<<EOF
      SELECT * FROM person WHERE fam_no={$famno}
EOF;

   $rett = $db->query($sqll);
   while($roww = $rett->fetchArray(SQLITE3_ASSOC) ){
      echo  "ناو :". $roww["p_first"] ." ". $roww["p_father"] ." ". $roww["p_grand"] ." <br>". "تەمەن =" . substr($roww["p_birth"], 0, -2)  ."<br>". " ژمارەی خێزان " . $roww["fam_no"] ."<br>". "\n" ;
   }';

   $db->close();
}
?>