<?php
session_start();

// Oturum açılmamışsa login sayfasına yönlendir
if (!isset($_SESSION['live'])) {
    header("Location: /dashboard");
    exit;
}

// Get user's IP address
$ip = $_SERVER['REMOTE_ADDR'];

// Define the path to the JSON file
$jsonFilePath = '/code/dashboard/B4BYLOG.json';

// Read login credentials from the JSON file
$credentials = file_get_contents($jsonFilePath);
$credentials = json_decode($credentials, true);

// Check if user's IP address is present in the JSON file
$ipFound = false;
foreach ($credentials['users'] as &$userData) {
    if ($ip == $userData['ip']) {
        $ipFound = true;
        break;
    }
}

// If IP is not found in the JSON file, destroy the session and redirect to the dashboard
if (!$ipFound) {
    session_destroy();
    header("Location: /index.php");
    exit;
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Enter Place</title>
</head>
<body>
    <form action="" method="post">
        <label for="place">Enter Place:</label><br>
        <input type="text" id="place" name="place"><br>
        <title>Plate Lookup</title>
   		<link rel="stylesheet" href="style.css">
        <label for="inputType">Select Type:</label><br>
        <select name="inputType">
            <option value="xsuse">خصوصي</option>
            <option value="taxi">تەکسی</option>
            <option value="7ml">حمل</option>
        </select><br>
        
        <input type="submit" value="Submit">
    </form>

    <?php
    if (isset($_POST['place'])) {
        $place = $_POST['place'];
        $sh = $_POST['inputType'];
        $shaa = $sh.'.sqlite';
        $db = new SQLite3($shaa);
        $results = $db->query("SELECT * FROM Sheet1 WHERE place='{$place}'");
        echo "<div class='thename'>" ;
        while ($row = $results->fetchArray(SQLITE3_ASSOC)) {
            echo "<div class='thename'>
            <p class='thep'>الاسم : " . $row["name"] . "</p>" . 
            "<p class='thep'>العنوان : " . $row["العنوان"] . "</p>" . 
            "<p class='thep'>السيارة : " . $row["نوع السيارة"] . "</p>" . 
            "<p class='thep'>الموديل : " . $row["موديل السيارة"] . "</p>" . 
            "<p class='thep'>اللون : " . $row["اللون"] . "</p>" . 
            "<p class='thep'>سلندر : " . $row["سلندر"] . "</p>" . 
            "<p class='thep'>نوع : " . $row["نوع"] . "</p>" . 
            "<p class='thep'>رقم الشاصي : " . $row["رقم الشاصي"] . "</p>" . 
            "<p class='thep'>رقم المحرك : " . $row["رقم المحرك"] . "</p>" . 
            "<p class='thep'>رقم السنوية : " . $row["رقم السنوية"] . "</p>" . 
            "<p class='thep'>مصدر السيارة : " . $row["مصدر السيارة"] . "</p>" . 
            "<p class='thep'>نوع التسجيل : " . $row["نوع التسجيل"] . "</p>" . 
            "<p class='thep'>كروبي ئوتوموبيل : " . $row["كروبي ئوتوموبيل"] . "</p>" . 
            "<p class='thep'>تاريخ التحويل : " . $row["تاريخ التحويل"] . "</p>" . 
            "<p class='thep'>تاريخ الاصدار : " . $row["تاريخ الاصدار"] . "</p>" . 
            "<p class='thep'>تاريخ الانتهاء : " . $row["تاريخ الانتهاء"] . "</p>" . 
            "<p class='thep'>تاريخ تسجيل اول مرة : " . $row["تاريخ تسجيل اول مرة"] . "</p>" . 
            "<p class='thep'>ملاحظات : " . $row["ملاحظات"] . "</p>" . 
            "<p class='thep'>وقود : " . $row["وقود"] . "</p></div>\n";

        }
        $db->close();
    }
    ?>
</body>
</html>