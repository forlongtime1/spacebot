<?php
session_start();

// Oturum açılmamışsa login sayfasına yönlendir
if (!isset($_SESSION['live'])) {
    header("Location: /dashboard");
    exit;
}

// Get user's IP address
$ip = $_SERVER['REMOTE_ADDR'];

// Define the path to the JSON file
$jsonFilePath = '/code/dashboard/B4BYLOG.json';

// Read login credentials from the JSON file
$credentials = file_get_contents($jsonFilePath);
$credentials = json_decode($credentials, true);

// Check if user's IP address is present in the JSON file
$ipFound = false;
foreach ($credentials['users'] as &$userData) {
    if ($ip == $userData['ip']) {
        $ipFound = true;
        break;
    }
}

// If IP is not found in the JSON file, destroy the session and redirect to the dashboard
if (!$ipFound) {
    session_destroy();
    header("Location: /index.php");
    exit;
}

?>
<?php

// JSON file path
$jsonFilePath = '/code/dashboard/B4BYLOG.json';

// Function to generate a random password
function generateRandomPassword($length = 10) {
    return substr(str_shuffle(str_repeat($x='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length/strlen($x)) )),1,$length);
}

// Function to add user to JSON file
function addUser($filePath, $user, $pass, $ip) {
    // Read existing JSON data from file
    $json_data = file_get_contents($filePath);

    // Decode JSON data
    $data = json_decode($json_data, true);

    // Add new user details
    $new_entry = array("user" => $user, "pass" => $pass, "ip" => $ip);
    $data['users'][] = $new_entry;

    // Encode the updated JSON data
    $updated_json_data = json_encode($data, JSON_PRETTY_PRINT);

    // Write the updated JSON data back to the file
    file_put_contents($filePath, $updated_json_data);

    return $new_entry;
}

// Initialize variables to hold user details
$userAdded = false;
$newUserDetails = array();

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $numPairs = intval($_POST['numPairs']);
    
    for ($i = 0; $i < $numPairs; $i++) {
        // Generate a username dynamically
        $base_username = $_POST['username'];
        $new_user = $base_username . ($i + 1); // Appending a unique number
        
        // Check if password is provided
        if (!empty($_POST['password'])) {
            $new_pass = $_POST['password'];
        } else {
            // Generate a random password
            $new_pass = generateRandomPassword();
        }
        
        $new_ip = $_POST['ip'];
        
        // Add user to JSON file
        $newUserDetails[] = addUser($jsonFilePath, $new_user, $new_pass, $new_ip);
    }
    
    $userAdded = true;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add User</title>
</head>
<body>
    <h2>Add User</h2>
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <!-- Input for number of user-pass pairs to generate -->
        <label for="numPairs">Number of User-Pass Pairs:</label><br>
        <input type="number" id="numPairs" name="numPairs" min="1" required><br><br>
        
        <!-- Input for base username -->
        <label for="username">Base Username:</label><br>
        <input type="text" id="username" name="username" required><br><br>
        
        <!-- Input for password -->
        <label for="password">Password:</label><br>
        <input type="password" id="password" name="password"><br><br>
        
        <!-- Input for IP address -->
        <label for="ip">IP Address:</label><br>
        <input type="text" id="ip" name="ip"><br><br>
        
        <input type="submit" value="Submit">
    </form>

    <?php if ($userAdded): ?>
        <h2>By @fbyme</h2>
        <?php foreach ($newUserDetails as $user): ?>
            <p>Username: <?php echo $user['user']; ?></p>
            <p>Password: <?php echo $user['pass']; ?></p>
            <hr>
        <?php endforeach; ?>
    <?php endif; ?>
</body>
</html>