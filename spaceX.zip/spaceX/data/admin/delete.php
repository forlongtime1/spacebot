<?php
session_start();

// Oturum açılmamışsa login sayfasına yönlendir
if (!isset($_SESSION['live'])) {
    header("Location: /dashboard");
    exit;
}

// Get user's IP address
$ip = $_SERVER['REMOTE_ADDR'];

// Define the path to the JSON file
$jsonFilePath = '/code/dashboard/B4BYLOG.json';

// Read login credentials from the JSON file
$credentials = file_get_contents($jsonFilePath);
$credentials = json_decode($credentials, true);

// Check if user's IP address is present in the JSON file
$ipFound = false;
foreach ($credentials['users'] as &$userData) {
    if ($ip == $userData['ip']) {
        $ipFound = true;
        break;
    }
}

// If IP is not found in the JSON file, destroy the session and redirect to the dashboard
if (!$ipFound) {
    session_destroy();
    header("Location: /index.php");
    exit;
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Search and Delete JSON Data</title>
</head>
<body>
    <h2>Search and Delete JSON Data</h2>
    <form method="post" action="">
        <label for="searchTerm">Enter User, Password, or IP:</label><br>
        <input type="text" id="searchTerm" name="searchTerm"><br><br>
        <input type="submit" value="Search">
    </form>

    <?php
    $jsonFilePath = '/code/dashboard/B4BYLOG.json';

    // Function to search for user, pass, or IP
    function search($data, $searchTerm) {
        $results = [];
        foreach ($data['users'] as $index => $user) {
            if ($user['user'] === $searchTerm || $user['pass'] === $searchTerm || $user['ip'] === $searchTerm) {
                $results[] = $user;
                // Store the index of the found user for deletion
                $GLOBALS['indexToDelete'] = $index;
            }
        }
        return $results;
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['searchTerm'])) {
        $searchTerm = $_POST['searchTerm'];

        // Read JSON file
        $jsonData = file_get_contents($jsonFilePath);

        // Decode JSON data
        $data = json_decode($jsonData, true);

        $searchResults = search($data, $searchTerm);

        // Display search results
        if (!empty($searchResults)) {
            echo "<h3>Search Results for '$searchTerm':</h3>";
            foreach ($searchResults as $result) {
                echo "User: " . $result['user'] . ", Pass: " . $result['pass'] . ", IP: " . $result['ip'] . "<br>";
                // Add a button to delete the user
                echo "<form method='post' action=''>
                        <input type='hidden' name='deleteIndex' value='" . $GLOBALS['indexToDelete'] . "'>
                        <input type='submit' value='Delete'>
                      </form>";
            }
        } else {
            echo "<h3>No results found for '$searchTerm'.</h3>";
        }
    }

    // Check if delete request is received
    if (isset($_POST['deleteIndex'])) {
        $indexToDelete = $_POST['deleteIndex'];
        // Read JSON file
        $jsonData = file_get_contents($jsonFilePath);
        // Decode JSON data
        $data = json_decode($jsonData, true);
        // Delete the user from the data array
        unset($data['users'][$indexToDelete]);
        // Encode and write back to the JSON file
        file_put_contents($jsonFilePath, json_encode($data, JSON_PRETTY_PRINT));
        echo "<h3>User deleted successfully.</h3>";
    }
    ?>
</body>
</html>